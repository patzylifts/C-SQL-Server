﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentEnrollmentSystem
{
    public partial class UserAdmin : Form
    {
        public UserAdmin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            login l = new login();
            this.Hide();
            l.Show();
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LoginAdmin l = new LoginAdmin();
            this.Hide();
            l.Show();
        }

        private void button1_MouseMove(object sender, MouseEventArgs e)
        {
            

        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            
        }
    }
}
