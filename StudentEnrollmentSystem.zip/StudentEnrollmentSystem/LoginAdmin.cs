﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentEnrollmentSystem
{
    public partial class LoginAdmin : Form
    {
        public LoginAdmin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-BS4T7T2\SQLEXPRESS;Initial Catalog=studentAccount;Integrated Security=True;Encrypt=False");
            con.Open();

            SqlDataAdapter sqa = new SqlDataAdapter("select count(*) from admin_tab where  Username = '" + textBox1.Text + "' and Password  = '" + textBox2.Text + "' ", con);
            DataTable table = new DataTable();
            sqa.Fill(table);

            if (table.Rows[0][0].ToString() == "1")
            {
               
                Admin admin = new Admin();
                admin.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("Invalid username or password!", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

           
        }

        private void LoginAdmin_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            UserAdmin a = new UserAdmin();
            a.Show();
            this.Hide();
        }
    }
}
