﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudentEnrollmentSystem
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

      
        private void button1_Click(object sender, EventArgs e)
        {
            
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-BS4T7T2\SQLEXPRESS;Initial Catalog=studentAccount;Integrated Security=True;Encrypt=False");
            con.Open();

            SqlDataAdapter sqa = new SqlDataAdapter("select count(*) from student_Acc where  Username = '"+textBox1.Text+ "' and Password  = '"+textBox2.Text+"' ", con);
            DataTable table = new DataTable();
            sqa.Fill(table);

            if (table.Rows[0][0].ToString() == "1")
            {
                this.Hide();
                Form1 f1 = new Form1(textBox1.Text + "!");
                f1.Show();
                MessageBox.Show("Welcome to CVSU Portal!", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else {
                MessageBox.Show("Invalid username or password!", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            /*  cmd.ExecuteNonQuery();
              con.Close();
              MessageBox.Show("Welcome!");
              Form1 f1 = new Form1(textBox1.Text + "!");
              f1.Show();
              this.Hide();
          */


        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Registration_form form = new Registration_form();
            form.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void login_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            UserAdmin a = new UserAdmin();
            a.Show();
            this.Hide();
        }
    }
}
