﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace StudentEnrollmentSystem
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-BS4T7T2\SQLEXPRESS;Initial Catalog=studentRdb;Integrated Security=True;Encrypt=False");


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
               
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-BS4T7T2\SQLEXPRESS;Initial Catalog=studentRdb;Integrated Security=True;Encrypt=False");

                con.Open();

                SqlCommand cnn = new SqlCommand("select * from student_tab  where Student_Number = @Student_Number ", con);

               cnn.Parameters.AddWithValue("@Student_Number", int.Parse(textBox1.Text));

                // cnn.Parameters.AddWithValue("@Student_Number", textBox1.Text);
              

               //  cnn.Parameters.AddWithValue("@Fullname", textBox1.Text.ToString());
                // cnn.Parameters.AddWithValue("@Age", int.Parse(textBox1.Text));
                // cnn.Parameters.AddWithValue("@Phone", int.Parse(textBox1.Text));
                // cnn.Parameters.AddWithValue("@Email", textBox1.Text);
              //   cnn.Parameters.AddWithValue("@Year", textBox1.Text.ToString());
               //  cnn.Parameters.AddWithValue("@Section", textBox1.Text.ToString());
               //  cnn.Parameters.AddWithValue("@Course", textBox1.Text.ToString());
               //  cnn.Parameters.AddWithValue("@Sex", textBox1.Text);
               //  cnn.Parameters.AddWithValue("@Address", textBox1.Text);
               //  cnn.Parameters.AddWithValue("@Birthdate", textBox1.Text);
                cnn.ExecuteNonQuery();
                textBox1.Text = "";
                SqlDataAdapter da = new SqlDataAdapter(cnn);
                cnn.ExecuteNonQuery();
                DataTable table = new DataTable();
                da.Fill(table);
                dataGridView1.DataSource = table;
                con.Close();
               // BindData();
                



                //try and catch
            }
            catch (Exception ee)
            {
               // MessageBox.Show(ee.Message);
               MessageBox.Show("Please input data correctly or data not exist!", "Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

        }

       

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Admin_Load(object sender, EventArgs e)
        {
        //   BindData();
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            con.Open();
            SqlCommand cnn = new SqlCommand("select * from student_tab", con);

            SqlDataAdapter da = new SqlDataAdapter(cnn);
            cnn.ExecuteNonQuery();
            DataTable table = new DataTable();
            da.Fill(table);
            dataGridView1.DataSource = table;
            con.Close();
        }
        public void BindData()
        {
            try
            {
                con.Open();
                SqlCommand cnn = new SqlCommand("select * from student_tab ");
                SqlDataAdapter da = new SqlDataAdapter(cnn);
                cnn.ExecuteNonQuery();
                DataTable table = new DataTable();
                da.Fill(table);
                dataGridView1.DataSource = table;
            }
            catch (Exception ee) {
                MessageBox.Show(ee.Message);
            }
          
          
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-BS4T7T2\SQLEXPRESS;Initial Catalog=studentRdb;Integrated Security=True;Encrypt=False");

                con.Open();


                SqlCommand cnn = new SqlCommand("delete student_tab where Student_Number =@Student_Number", con);

                if (MessageBox.Show("Are you sure want to delete?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cnn.Parameters.AddWithValue("@Student_Number", int.Parse(textBox2.Text));
                    MessageBox.Show("Delete Success!", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    cnn.ExecuteNonQuery();
                    textBox2.Text = "";

                }
                SqlDataAdapter da = new SqlDataAdapter(cnn);
                cnn.ExecuteNonQuery();
                DataTable table = new DataTable();
                da.Fill(table);
                dataGridView1.DataSource = table;



            }
            catch (Exception ee)
            {
               // MessageBox.Show(ee.Message);
                MessageBox.Show("Please input Student Number only, or the Student number you input is not correct.", "Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                con.Close();
              

            }
        }

        private void btnUpd_Click(object sender, EventArgs e)
        {
            UpdateInfoStud u = new UpdateInfoStud();
            u.Show();
            this.Hide();

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            UserAdmin a = new UserAdmin();
            a.Show();
            this.Hide();
        }
    }
}
