﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudentEnrollmentSystem
{
    public partial class Form1 : Form
    {
        public String name;
        public Form1(String Name)
        {
            name = Name;
            InitializeComponent();

        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-BS4T7T2\SQLEXPRESS;Initial Catalog=studentRdb;Integrated Security=True;Encrypt=False");
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
        
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-BS4T7T2\SQLEXPRESS;Initial Catalog=studentRdb;Integrated Security=True;Encrypt=False");

                con.Open();
            
                SqlCommand cnn = new SqlCommand("insert into student_tab values(@Student_Number,@Fullname,@Age,@Email,@Phone,@Year, @Section, @Course,@Sex,@Address,@Birthdate)", con);
            
                cnn.Parameters.AddWithValue("@Student_Number", int.Parse(textBox1.Text));
                cnn.Parameters.AddWithValue("@Fullname", textBox2.Text);
                cnn.Parameters.AddWithValue("@Age", int.Parse(textBox3.Text));
                cnn.Parameters.AddWithValue("@Phone", textBox4.Text);
                cnn.Parameters.AddWithValue("@Email", textBox5.Text);
                cnn.Parameters.AddWithValue("@Year", textBox10.Text);
                cnn.Parameters.AddWithValue("@Section", textBox11.Text);
                cnn.Parameters.AddWithValue("@Course", textBox6.Text);
                cnn.Parameters.AddWithValue("@Sex", textBox7.Text);
                cnn.Parameters.AddWithValue("@Address", textBox8.Text);
                cnn.Parameters.AddWithValue("@Birthdate", textBox9.Text);
                cnn.ExecuteNonQuery();
                con.Close();

                //      BindData();

         

                MessageBox.Show("Register Successfully", "Register", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //try and catch
          }
         catch (Exception ee)
            {
                MessageBox.Show("Please input data correctly or entry duplicates an existing record!", "Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                con.Close();
            }
         


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //    BindData();
            label17.Text = name;

        }

       

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            deleteAll();
        }
        public void deleteAll() {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            textBox11.Text = "";
        }
        private void btnDel_Click(object sender, EventArgs e)
        {

            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-BS4T7T2\SQLEXPRESS;Initial Catalog=studentRdb;Integrated Security=True;Encrypt=False");

                con.Open();


                SqlCommand cnn = new SqlCommand("delete student_tab where Student_Number =@Student_Number", con);
              
               //  SqlCommand cnn = new SqlCommand("if exists(select * from  student_tab where Student_Number =@Student_Number ) begin  delete student_tab where Student_Number =@Student_Number end", con);
                // SqlCommand cnn = new SqlCommand("delete from student_tab where Student_Number = @Student_Number begin if exists(select * from  student_tab where Student_Number =@Student_Number ) begin  delete student_tab where Student_Number =@Student_Number end end", con);
                //   SqlCommand cnn = new SqlCommand("SELECT  *FROM student_tab WHERE NOT EXISTS (DELETE  student_tab WHERE Student_Number = @Student_Number)", con);
                //      cnn.Parameters.AddWithValue("Student_Number", int.Parse(textBox1.Text));
                //   SqlDataReader myeader = cnn.ExecuteReader();
                 if (MessageBox.Show("Are you sure want to delete?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                    cnn.Parameters.AddWithValue("@Student_Number", int.Parse(textBox1.Text));
                    MessageBox.Show("Delete Success!", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    cnn.ExecuteNonQuery();
                    deleteAll();
                }
              
                /*    if (myeader.Read())
                    { */
               
                
                //  }
                //   else {
                //      MessageBox.Show("Delete Fail", "Data Not exists!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                //   }
                ///   BindData();
              //  cnn.ExecuteNonQuery();
                con.Close();
                    

            } catch (Exception ee) {

                MessageBox.Show("Please input Student Number only, or the Student number you input is not correct.", "Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
               
                con.Close();
                deleteAll();

            }
                


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)

        {
            
            try
            {

                con.Open();
                SqlCommand cnn = new SqlCommand("update  student_tab set Fullname = @Fullname,Age = @Age,Email = @Email,Phone = @Phone,Year = @Year ,Section = @Section,Course = @Course, Sex = @Sex, Address = @Address, Birthdate = @Birthdate where Student_Number = @Student_Number", con);
             

                //      SqlDataAdapter da = new SqlDataAdapter(cnn);


                cnn.Parameters.AddWithValue("@Student_Number", int.Parse(textBox1.Text)); 
                cnn.Parameters.AddWithValue("@Fullname", textBox2.Text);
                cnn.Parameters.AddWithValue("@Age", int.Parse(textBox3.Text));
                cnn.Parameters.AddWithValue("@Phone", textBox4.Text);
                cnn.Parameters.AddWithValue("@Email", textBox5.Text);
                cnn.Parameters.AddWithValue("@Year", textBox10.Text);
                cnn.Parameters.AddWithValue("@Section", textBox11.Text);
                cnn.Parameters.AddWithValue("@Course", textBox6.Text);
                cnn.Parameters.AddWithValue("@Sex", textBox7.Text);
                cnn.Parameters.AddWithValue("@Address", textBox8.Text);
                cnn.Parameters.AddWithValue("@Birthdate", textBox9.Text);


                

                cnn.ExecuteNonQuery();

                con.Close();
                //       BindData();

                MessageBox.Show("Updated Successfully", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
               
            }
            catch (Exception ee)
            {
            
                MessageBox.Show("The student number you entered is not valid or the student number you entered is no longer valid. Please check it and try again.", "Update,", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                con.Close();

            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            login l = new login();
            l.Show();
            this.Hide();
        }
    }
}
